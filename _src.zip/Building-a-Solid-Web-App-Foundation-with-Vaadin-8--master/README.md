## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/building-a-solid-web-app-foundation-with-vaadin-8-video/9781788294492)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Building a Solid Web App Foundation with Vaadin 8 [Video]
This is the code repository for [Building a Solid Web App Foundation with Vaadin 8 [Video]](https://www.packtpub.com/application-development/building-solid-web-app-foundation-vaadin-8-video?utm_source=github&utm_medium=repository&utm_campaign=9781788294492), published by [Packt](https://www.packtpub.com/?utm_source=github). It contains all the supporting project files necessary to work through the video course from start to finish.
## About the Video Course
The course will kick start your Web Application development project by guiding you in laying out the User Interface foundation the right way on the first time. During this two hour course you will learn how server-driven Web Application framework helps you exceed your current development performance and will show you hands on how to build a scalable and robust Vaadin User Interface foundation that works on desktop and mobile devices.	

<H2>What You Will Learn</H2>
<DIV class=book-info-will-learn-text>
<UL>
<LI>Package, align, and deploy modular web applications 
<LI>Build component-based web applications that are event-driven 
<LI>Create beautiful layouts that react to device orientation 
<LI>Find out how the concept of views in a business app can be realized 
<LI>Discover how in-app navigation can be implemented with good design </LI></UL></DIV>

## Instructions and Navigation
### Assumed Knowledge
To fully benefit from the coverage included in this course, you will need:<br/>
This course is intended for developers striving for efficiency and high-quality UI’s with Vaadin Framework. Full-stack developers working with Java on both frontend and backend systems and who want to efficiently utilize Java in their User Interfaces. 

### Technical Requirements
This course has the following software requirements:<br/>
NA

## Related Products
* [Building a Solid Web App Foundation with Vaadin 8 [Video]](https://www.packtpub.com/application-development/building-solid-web-app-foundation-vaadin-8-video?utm_source=github&utm_medium=repository&utm_campaign=9781788294492)

* [CISSP®️ Certification Domain 3: Security Architecture and Engineering Video Boot Camp 2019 [Video]](https://www.packtpub.com/application-development/cissp-certification-domain-3-security-architecture-and-engineering-video?utm_source=github&utm_medium=repository&utm_campaign=9781838646080)

* [CISSP®️ Certification Domain 3: Security Architecture and Engineering Video Boot Camp 2019 [Video]](https://www.packtpub.com/application-development/cissp-certification-domain-3-security-architecture-and-engineering-video?utm_source=github&utm_medium=repository&utm_campaign=9781838646080)

